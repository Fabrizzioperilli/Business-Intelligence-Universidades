from dash import html
from callbacks.gestor.callback_resumen_gestor import update_resumen_gestor

def resumen_gestor():
    return html.Div([
    ], id='resumen-gestor')