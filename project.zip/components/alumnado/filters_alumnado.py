from dash import html, dcc
from data.db_connector import db

def filters_alumnado():
    query = "SELECT curso_aca FROM matricula WHERE id = '1SI0Y8K3'"
    result = db.execute_query(query)
    
    # Convierte los resultados en una lista de diccionarios (etiqueta-valor) para el Dropdown
    opciones_dropdown = [{'label': curso[0], 'value': curso[0]} for curso in result]

    # Crea el componente HTML con el Dropdown
    return html.Div([
        html.H2("Filtros"),
        html.Label("Curso Académico"),
        dcc.Dropdown(
            id='curso-academico',
            searchable=False,
            clearable=False,
            options=opciones_dropdown,
            value=opciones_dropdown[0]['value'] if opciones_dropdown else None  # Asegura que hay opciones
        )
    ], className='filters')