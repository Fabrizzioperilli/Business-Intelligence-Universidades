from dash import html, dcc
from data.db_connector import db

def select_alumnado():
    query = "SELECT id DISTINCT FROM alumnos"
    result = db.execute_query(query)
    opciones_dropdown = [{'label': alumno[0], 'value': alumno[0]} for alumno in result]
    
    return html.Div([
        html.Div([
            dcc.Dropdown(
                options=opciones_dropdown,
                value=opciones_dropdown[0]['value'] if opciones_dropdown else None,
                id='tabs-alumnado',
                clearable=False,
                
            )
        ], className='select-alumnado'),
    ])


