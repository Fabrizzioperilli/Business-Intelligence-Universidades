from dash import html
from components.alumnado.select_alumnado import select_alumnado
from callbacks.alumnado.callback_update_resumen_alumnado import update_resumen_alumnado

def resumen_alumnado():
    return html.Div([
    ], id='resumen-alumnado')
    
