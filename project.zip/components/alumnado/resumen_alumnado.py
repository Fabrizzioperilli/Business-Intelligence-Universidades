from dash import html
from dash import html
from data.db_connector import db

def resumen_alumnado():
    query = "SELECT universidad, titulacion, id FROM matricula WHERE id = :id"
    params = {'id': '1SI0Y8K3'}
    result = db.execute_query(query, params)

    if result:
        universidad = result[0][0]
        titulacion = result[0][1]
        id = result[0][2]
    else:
        universidad = titulacion = id = "No disponible"

    return html.Div([
        html.H2("Resumen"),
        html.P(f"Universidad: {universidad}"), 
        html.P(f"Titulación: {titulacion}"),
        html.P(f"Alumno: {id}"),
        html.P(f"Nota Media: "),
        html.Hr(),
    ])
